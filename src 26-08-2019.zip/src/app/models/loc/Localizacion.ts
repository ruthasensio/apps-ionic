export default class LocalizacionModel {
    constructor (
        public lat: number,
        public lon: number
    ) {}
}