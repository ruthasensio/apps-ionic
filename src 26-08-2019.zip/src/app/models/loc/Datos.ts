export default class DatosModel {
    constructor (
        public gender: number,
        public name: string,
        public last: string,
        public picture: string
    ) {       
   
    }

    
}