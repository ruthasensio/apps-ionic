export default class ExtraModel {
    constructor (
        public extra: any
    ) {}
}