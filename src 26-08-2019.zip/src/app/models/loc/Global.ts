export default class GlobalizationModel {
    constructor (
        public language: any
    ) {}
}