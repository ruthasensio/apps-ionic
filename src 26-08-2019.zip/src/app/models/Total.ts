export default class TotalModel {
    constructor (
        public pages: any
    ) {       
   
    }

    
}